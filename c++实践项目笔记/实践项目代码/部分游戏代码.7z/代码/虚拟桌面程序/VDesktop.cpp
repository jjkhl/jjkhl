#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <windows.h>
#include "resource.h"
HINSTANCE g_hInst;
HWND	g_hMainWnd;
HDESK hvirtualDesk[10];    //����������
PROCESS_INFORMATION pi; //������������Ϣ
NOTIFYICONDATA NotifyIcon;
DWORD dwIconID;
#define WM_ICON WM_USER+101
#define IDM_EXIT WM_USER+1001
// ����Ⱥ��:361646062
// �Լ�QQ��:570427370
// VIP�γ�:921700006
void RunExplorer(char *szVDesktopName)
{
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.lpDesktop = szVDesktopName;
	ZeroMemory(&pi, sizeof(pi));

	if (!CreateProcess(NULL,"explorer",NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
	{
		MessageBox(NULL, "�����ļ�������ʧ��", "Error", 0);
		ExitProcess(1);
	}
}
//����������������һ����������ʵ��
void RunCalc(char * szVDesktopName)
{
	STARTUPINFO si;
	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	si.lpDesktop = szVDesktopName;
	ZeroMemory(&pi, sizeof(pi));

	if (!CreateProcess(NULL,"calc",NULL,NULL,FALSE,0,NULL,NULL,&si,&pi))
	{
		MessageBox(NULL, "���м�����ʧ��", "Error", 0);
		ExitProcess(1);
	}
}
void OnStartVDesktop(HWND hWnd)
{
	MessageBox(hWnd,"Ready to start virtual desktop","information",MB_OK | MB_ICONINFORMATION);
	char szVDesktopName[30];
	for (int i = 1; i < 10;i++)
	{
		RtlZeroMemory(szVDesktopName, 30);
		sprintf_s(szVDesktopName, 30, "myDesktop%d", i);
		hvirtualDesk[i] = CreateDesktopA(szVDesktopName, NULL, NULL, DF_ALLOWOTHERACCOUNTHOOK, GENERIC_ALL, NULL);
		RunExplorer(szVDesktopName);
		RunCalc(szVDesktopName);
	}
	ShowWindow(hWnd,SW_HIDE);
	return;
}
void OnHotKey(HWND hWnd,int n)
{
	SwitchDesktop(hvirtualDesk[n]);
	SetThreadDesktop(hvirtualDesk[n]);
	UpdateWindow(hWnd);
	return;
}
BOOL CALLBACK CloseDesktopWindows(HWND hWnd,LPARAM lParam)
{
	DWORD dwTargetPID;
	::GetWindowThreadProcessId(hWnd, &dwTargetPID);
	HANDLE hTarget = OpenProcess(PROCESS_ALL_ACCESS,false,dwTargetPID);
	printf("find hWnd = %08X pid = %08d HANDLE = %08X\n",hWnd,dwTargetPID,hTarget);
	TerminateProcess(hTarget,1);
	return true;
}
void OnClose(HWND hWnd)
{
	memset(&NotifyIcon, 0, sizeof(NOTIFYICONDATA));
	NotifyIcon.hWnd = g_hMainWnd;
	NotifyIcon.uID = dwIconID;
	Shell_NotifyIcon(NIM_DELETE, &NotifyIcon);
	// TerminateProcess( pi.hProcess, 1 );
	for (int i = 1; i < 10 && hvirtualDesk[i];i++)
	{
		EnumDesktopWindows(hvirtualDesk[i],CloseDesktopWindows,0);
		CloseDesktop(hvirtualDesk[i]);
	}
	DestroyWindow(hWnd);
	PostQuitMessage(0);
	return;
}
// ���� : 	��ʼ���Ի���ʱ���� 
// ���� : 	hWnd ���ھ��
// ����ֵ : ��ʼ�������Ƿ�ɹ�
BOOL OnInitDialog(HWND hWnd)
{
	for (int i = 0; i < 10 ; i++)
	{
		hvirtualDesk[i] = 0;
	}
	hvirtualDesk[0] = GetThreadDesktop(GetCurrentThreadId()); 
	for (int i = 0; i < 10; i++)
	{
		char szBuf[MAX_PATH];
		sprintf_s(szBuf, MAX_PATH, "ZS Virtual Desktop %d", i);
		DWORD ret = RegisterHotKey(hWnd, 0, MOD_CONTROL | MOD_ALT, 0x30+i);
		if (ret == 0)
		{
			sprintf_s(szBuf, "ע��ϵͳ�ȼ� Ctrl+Alt+%d ʧ��", i);
			MessageBoxA(hWnd, szBuf, 0, 0);
			PostQuitMessage(0);
		}
	}
	// ��������ͼ��
	NotifyIcon.cbSize = sizeof(NOTIFYICONDATA);
	NotifyIcon.hIcon = LoadIcon(g_hInst, MAKEINTRESOURCE(IDI_ICON1));
	NotifyIcon.hWnd = hWnd;
	strcpy(NotifyIcon.szTip, "ZS���������ϵͳ");
	NotifyIcon.uCallbackMessage = WM_ICON;
	dwIconID = GlobalAddAtom("ZS Virtual Desktop");
	NotifyIcon.uID = dwIconID;
	NotifyIcon.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
	Shell_NotifyIcon(NIM_ADD, &NotifyIcon);
	return TRUE;
}
INT_PTR CALLBACK DlgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_INITDIALOG:
		g_hMainWnd = hWnd;
		OnInitDialog(hWnd);
		break;
	case WM_HOTKEY:
		if (LOWORD(lParam) == (MOD_CONTROL | MOD_ALT))
		{
			OnHotKey(hWnd,HIWORD(lParam) - 0x30);
		}
		break;
	// ������Ӧ��Ϣ
	case WM_ICON:
		if (lParam == WM_RBUTTONUP)
		{
			SetWindowPos(hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SW_SHOW);
			SetWindowPos(hWnd, HWND_TOP, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SW_SHOW);
			HMENU hMenu = CreatePopupMenu();
			AppendMenu(hMenu, MF_STRING, IDM_EXIT, "�˳�");

			POINT point;
			GetCursorPos(&point);
			TrackPopupMenu(hMenu, TPM_RIGHTALIGN, point.x, point.y, 0, hWnd, NULL);
			::PostMessage(hWnd, WM_NULL, 0, 0);
			return TRUE;
		}
		else if (lParam == WM_LBUTTONUP)
		{
			ShowWindow(hWnd, SW_SHOW);
		}
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDM_EXIT:
			SendMessage(hWnd,WM_CLOSE,0,0);
			break;
		case IDC_BTN_START:
			OnStartVDesktop(hWnd);
			break;
		default:
			break;
		}
		return TRUE;
	case WM_DESTROY:
		OnClose(hWnd);
		PostQuitMessage(0);
	case WM_CLOSE:
		OnClose(hWnd);
		PostQuitMessage(0);
		return TRUE;
	default:
		return FALSE;
	}
	return  FALSE;
}
//�������ؽ��̵�Ȩ��
BOOL EnablePriv()
{
	HANDLE hToken;
	//���� Token
	if(OpenProcessToken(GetCurrentProcess(),TOKEN_ADJUST_PRIVILEGES,&hToken))
	{
		TOKEN_PRIVILEGES tkp;
		LookupPrivilegeValue(NULL,SE_DEBUG_NAME,&tkp.Privileges[0].Luid);
		tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
		tkp.PrivilegeCount =1;
		AdjustTokenPrivileges(hToken,FALSE,&tkp,sizeof(tkp),NULL,NULL);
		return true;
	}
	return false;
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd)
{
	EnablePriv();
	if (AttachConsole(-1) != 0)
	{
		freopen("conin$", "r+t", stdin);
		freopen("conout$", "w+t", stdout);
		freopen("conout$", "w+t", stderr);
	}
	g_hInst = hInstance;
	g_hMainWnd = CreateDialog(hInstance, MAKEINTRESOURCE(IDD_CLIENT_DIALOG), GetDesktopWindow(), DlgProc);
	if (g_hMainWnd == 0)
	{
		return -1;
	}
	RECT wndRect;
	GetWindowRect(g_hMainWnd, &wndRect);
	int nScreenX = GetSystemMetrics(SM_CXSCREEN);
	int nScreeny = GetSystemMetrics(SM_CYSCREEN);

	SetWindowPos(g_hMainWnd, HWND_TOP, nScreenX / 2 - (wndRect.right - wndRect.left) / 2,
		nScreeny / 2 - (wndRect.bottom - wndRect.top) / 2, 0, 0, SWP_NOSIZE | SWP_SHOWWINDOW);

	MSG msg;
	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return 0;
}