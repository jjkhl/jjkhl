// ���ƽ�ʦ��	������ʦ
// QQ  :    	570427370
// ����Ⱥ��		431493983
// �����ͷ�QQ: 	921700006
// undercover

#include "stdafx.h"
#include <winsock2.h>
#include "Audio.h"
#pragma comment(lib,"ws2_32.lib")
#define  PORT 5000

int _tmain(int argc, _TCHAR* argv[])
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("WSAStartup failed\n");
		return -1;
	}

	SOCKET sServer = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sServer == INVALID_SOCKET)
	{
		printf("socket failed\n");
		return -1;
	}
	SOCKADDR_IN addrServ;
	addrServ.sin_family = AF_INET;
	addrServ.sin_port = htons(PORT);
	addrServ.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");

	int ret = connect(sServer, (sockaddr *)&addrServ, sizeof(SOCKADDR_IN));
	if (SOCKET_ERROR == ret)
	{
		printf("socket connect failed\n");
		WSACleanup();
		closesocket(sServer);
		return -1;
	}
	printf("�����ӷ�����...\n");
	CAudio * myAudio = new CAudio();
	while (TRUE)
	{
		DWORD dwRecv;
		BYTE buf[10240];
		memset(buf, 0, sizeof(buf));
		dwRecv = recv(sServer, (char *)buf, sizeof(buf), 0);
		printf("i have recv some audio,now,play...\n");
		if (dwRecv)
		{
			myAudio->playBuffer(buf, dwRecv);
		}
	}
	delete	myAudio;
	return 0;
}

