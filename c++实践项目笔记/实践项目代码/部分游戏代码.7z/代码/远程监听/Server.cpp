// ���ƽ�ʦ��	������ʦ
// QQ  :    	570427370
// ����Ⱥ��		431493983
// �����ͷ�QQ: 	921700006
// undercover

#include "stdafx.h"
#include <WinSock2.h>
#pragma comment(lib,"ws2_32.lib")
#include "Audio.h"
#define  PORT 5000
int _tmain(int argc, _TCHAR* argv[])
{
	WSADATA wsa;
	if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0)
	{
		printf("WSAStartup failed\n");
		return -1;
	}
	SOCKET sServer = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
	if (sServer == INVALID_SOCKET)
	{
		printf("socket failed\n");
		return -1;
	}
	SOCKADDR_IN addrServ;
	addrServ.sin_family = AF_INET;
	addrServ.sin_port = htons(PORT);
	addrServ.sin_addr.S_un.S_addr = INADDR_ANY;

	int ret = bind(sServer, (sockaddr *)&addrServ, sizeof(sockaddr));//��
	if (SOCKET_ERROR == ret)
	{
		printf("socket bind failed\n");
		WSACleanup();
		closesocket(sServer);
		return -1;
	}

	ret = listen(sServer, SOMAXCONN);  //����
	if (SOCKET_ERROR == ret)
	{
		printf("socket listen failed\n");
		WSACleanup();
		closesocket(sServer);
		return -1;
	}
	sockaddr_in addrClient;
	int addrClientLen = sizeof(sockaddr_in);
	printf("now i'm waiting for client...\n");
	SOCKET sClient = accept(sServer, (sockaddr*)&addrClient, &addrClientLen);
	if (INVALID_SOCKET == sClient)
	{
		printf("socket accept failed\n");
		WSACleanup();
		closesocket(sServer);
		return -1;
	}
	printf("someone connect to server...\n");
	CAudio * myAudio = new CAudio();
	while (TRUE)
	{
		DWORD	dwBytes = 0;
		UINT	nSendBytes = 0;
		LPBYTE	lpBuffer = myAudio->getRecordBuffer(&dwBytes);
		if (lpBuffer == NULL)
			return 0;
		printf("sending audio to client...\n");
		nSendBytes = sendto(sClient, (char *)lpBuffer, dwBytes, 0, (sockaddr *)&addrClient, addrClientLen);
		if (SOCKET_ERROR == nSendBytes)
		{
			printf("connection closed\n");
			break;
		}
	}
	delete	myAudio;
	system("pause");
	return 0;
}

